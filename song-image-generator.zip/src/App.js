import React from 'react';
import logo from './logo.svg';
import './reset.css';
import './App.css';
import MainContainer from './Components/MainContainer/MainContainer.jsx'

const clientId = "6e1dde8891e74eec96e04dfd313e1ebc";

function App() {
  return (
    <div className="App">
      <MainContainer />
    </div>
  );
}

export default App;
