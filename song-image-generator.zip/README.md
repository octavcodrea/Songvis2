
## Songvis
a WIP React app by Octav Codrea

This app connects to the Spotify API and allows searching for songs.

Using Spotify's data about the song's features (energy, valence, danceability, etc.) the app procedurally generates a vizualisation of the data. Slower, moodier songs will have darker colors and softer shapes while energetic, joyful songs will have highly saturated colors and edgier shapes.
